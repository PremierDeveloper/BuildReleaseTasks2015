## This is a simple script to demonstrate calling PowerShell scripts from a TFS PowerShell Build task. 
## Key points
## - Create a variable named "DynamicVariable" and show how to change a variable in a PowerShell script.
##   - Refer to https://github.com/Microsoft/vso-agent-tasks/issues/375 & 
##     https://github.com/Microsoft/vso-agent-tasks/blob/master/docs/authoring/commands.md

# The following will appear in the console output and task specific log in normal text.
Write-Host "PowerShell Test, The inbound variable is set as follows:"
Write-Host "DynamicVariable: $env:DynamicVariable"

# Set the DynamicVariable to a new value that is visible only in this task.
$env:DynamicVariable = "Temporary Value Set In Script"

# Set the DynamicVariable to a new value that is visible in subsquent tasks.
Write-Host "##vso[task.setvariable variable=DynamicVariable]Persistent Value Set In Script"

# The following will appear in the console output and task specific log in normal text.
Write-Host "PowerShell Test, The variable is currently set as follows:"
Write-Host "DynamicVariable: $env:DynamicVariable"

exit 0
