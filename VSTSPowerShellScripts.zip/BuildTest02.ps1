## This is a simple script to demonstrate calling PowerShell scripts from a TFS PowerShell Build task. 
## Key points
## - Create a variable named "EmulateScriptError" and set it to true to show how to return errors from a PS script.
##   Refer to https://msdn.microsoft.com/en-us/Library/vs/alm/Build/scripts/variables
## - Create a variable named "DynamicVariable" and show how to change a variable in a PowerShell script.
##   - Refer to https://github.com/Microsoft/vso-agent-tasks/issues/375 & 
##     https://github.com/Microsoft/vso-agent-tasks/blob/master/docs/authoring/commands.md
## - Note the use of "Write-Host, Write-Warning and Write-Error and how each show up in the Build log for this script"
## - Note how you can have error and warning information appear in the Build Summary.
##   - Refer to https://github.com/Microsoft/vso-agent-tasks/issues/573 & 
##     https://github.com/Microsoft/vso-agent-tasks/blob/master/docs/authoring/commands.md
## - To display your own information on the Build Summary refer to:
##   https://github.com/Microsoft/vsts-extension-samples Look specifically at the "Build Results Enhancer" section. 
##   NOTE: This is not implemented in this example.
## - To write information, warnings or errors to the task specific log file use Write-Host, Write-Warning, Write-Error.
##   Write-Host generates normal text. 
##   Write-Warning generates Yellow text. 
##   Write-Error generates Red text. 
## - Refer to https://github.com/Microsoft/vso-agent-tasks/blob/master/docs/authoring/commands.md
##	 for addtional commands that you can run in a PowerShell script, for example
##   - ##vso[task.setprogress value=75;]Step Name 
##   - ##vso[task.complete result=Succeeded;]DONE
##   - Additional commands not shown in the example script:
##     - Create and update detail timeline records
##     - Upload and attach attachment to current timeline record. 
##     - Upload and attach summary markdown to current timeline record

# The following will appear in the console output and task specific log in normal text.
Write-Host "PowerShell Test, The variables are set as follows:"
Write-Host "EmulateScriptError: $env:EmulateScriptError"
Write-Host "DynamicVariable: $env:DynamicVariable"

# Set progress and current operation for current task.
Write-Host "Begin a lengthy process..."
$i=0
While ($i -le 100)
{
	Start-Sleep 1
	Write-Host "##vso[task.setprogress value=$i;]Sample Progress Indicator"
	$i += 10
}
Write-Host "Lengthy process is complete."

# The following will appear in the console output preceded by "WARNING: " 
Write-Warning "This is a warning generated in a PowerShell script"

# The following will appear Build Summary as a Warning and in the task specific log in YELLOW text.
Write-Host "##vso[task.logissue type=warning;] PowerShell Warning Test"

if ($env:EmulateScriptError -eq "true") 
{
	# The following will appear in the console output preceded by "ERROR: ".
	Write-Error "This is an error generated in a PowerShell script"

	# The following will appear Build Summary as an Error and in the task specific log in YELLOW text.
	Write-Host "##vso[task.logissue type=error;] PowerShell Error Test"

	Write-Host "Build Task Failed"
    exit 1
}
else
{
	Write-Host "Build Task Succeeded"
	exit 0
}
